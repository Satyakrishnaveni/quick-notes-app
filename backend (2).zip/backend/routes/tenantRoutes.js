const express = require("express");
const router = express.Router();
const { protect } = require("../middleware/authMiddleware");
const { authorize } = require("../middleware/roleMiddleware");
const { upgradePlan } = require("../controllers/tenantController");

// Admin only upgrade endpoint
router.post("/:slug/upgrade", protect, authorize("Admin"), upgradePlan);

module.exports = router;
