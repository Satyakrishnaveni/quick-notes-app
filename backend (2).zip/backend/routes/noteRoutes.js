// const express = require("express");
// const router = express.Router();
// // const { protect } = require("../middleware/authMiddleware");
// const { authMiddleware, protect } = require("../middleware/authMiddleware");
// const { createNote, getNotes, getNote, updateNote, deleteNote } = require("../controllers/notesController");

// router.use(protect);

// router.post("/", createNote);
// router.get("/", getNotes);
// router.get("/:id", getNote);
// router.put("/:id", updateNote);
// router.delete("/:id", deleteNote);

// module.exports = router;





const { protect } = require("../middleware/automiddleware");
const Note = require("../models/Note");
const Tenant = require("../models/Tenant");

// Middleware definitions
const ensureTenant = (req, res, next) => {
  if (!req.user || !req.user.tenant) {
    return res.status(401).json({ message: "Unauthorized" });
  }
  req.tenantId = req.user.tenant._id.toString();
  next();
};

const enforceNoteLimit = async (req, res, next) => {
  try {
    const tenant = await Tenant.findById(req.tenantId);
    if (!tenant) return res.status(400).json({ message: "Tenant not found" });

    if (tenant.plan === "pro") return next();

    const count = await Note.countDocuments({ tenant: req.tenantId });
    const MAX_FREE = 3;
    if (count >= MAX_FREE) {
      return res.status(403).json({ message: `Free plan limit reached (${MAX_FREE} notes). Upgrade to Pro.` });
    }
    next();
  } catch (err) {
    next(err);
  }
};

// 🔹 Debug line – paste here, middleware define అయ్యాక
console.log("protect:", protect);
console.log("ensureTenant:", ensureTenant);
console.log("enforceNoteLimit:", enforceNoteLimit);

// Router.post(), router.get() etc. follow
router.post("/", protect, ensureTenant, enforceNoteLimit, async (req, res) => {  });
