// const express = require("express");
// const router = express.Router();
// const jwt = require("jsonwebtoken");
// const User = require("../models/User");

// // POST /login
// router.post("/login", async (req, res) => {
//   try {
//     const { email, password } = req.body;

//     // Check if user exists
//     const user = await User.findOne({ email }).populate("tenant");
//     if (!user) {
//       return res.status(401).json({ message: "Invalid credentials" });
//     }

//     // Check password
//     const isMatch = await user.matchPassword(password);
//     if (!isMatch) {
//       return res.status(401).json({ message: "Invalid credentials" });
//     }

//     // Generate JWT token
//     const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET, {
//       expiresIn: "1d",
//     });

//     res.json({
//       token,
//       role: user.role,
//       tenant: user.tenant?.name || null,
//     });

//   } catch (error) {
//     console.error("Login error:", error);
//     res.status(500).json({ message: "Server error" });
//   }
// });

// module.exports = router;



const express = require("express");
const router = express.Router();
const jwt = require("jsonwebtoken");
const User = require("../models/User");
const Note = require("../models/Note");
const Tenant = require("../models/Tenant");

// Middleware
const { authMiddleware } = require("../middleware/authMiddleware");
const { requireRole } = require("../middleware/roleMiddleware");

// --------------------- LOGIN ROUTE ---------------------
router.post("/login", async (req, res) => {
  try {
    const { email, password } = req.body;

    // Check if user exists
    const user = await User.findOne({ email }).populate("tenant");
    if (!user) {
      return res.status(401).json({ message: "Invalid credentials" });
    }

    // Check password
    const isMatch = await user.matchPassword(password);
    if (!isMatch) {
      return res.status(401).json({ message: "Invalid credentials" });
    }

    // Generate JWT token
    const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET, {
      expiresIn: "1d",
    });

    res.json({
      token,
      role: user.role,
      tenant: user.tenant?.name || null,
    });
  } catch (error) {
    console.error("Login error:", error);
    res.status(500).json({ message: "Server error" });
  }
});

// --------------------- TENANT CHECK MIDDLEWARE ---------------------
const ensureTenant = (req, res, next) => {
  if (!req.user || !req.user.tenant) {
    return res.status(401).json({ message: "Unauthorized" });
  }
  req.tenantId = req.user.tenant.toString();
  next();
};

// --------------------- FREE PLAN LIMIT MIDDLEWARE ---------------------
const enforceNoteLimit = async (req, res, next) => {
  try {
    const tenant = await Tenant.findById(req.tenantId);
    if (!tenant) return res.status(400).json({ message: "Tenant not found" });

    if (tenant.plan === "pro") return next();

    const count = await Note.countDocuments({ tenant: req.tenantId });
    const MAX_FREE = 3;
    if (count >= MAX_FREE) {
      return res
        .status(403)
        .json({ message: `Free plan limit reached (${MAX_FREE} notes). Upgrade to Pro.` });
    }

    next();
  } catch (err) {
    next(err);
  }
};

// --------------------- NOTES CRUD ---------------------

// CREATE NOTE
router.post("/", authMiddleware, ensureTenant, enforceNoteLimit, async (req, res) => {
  try {
    const { title, content } = req.body;
    if (!title) return res.status(400).json({ message: "Title is required" });

    const note = await Note.create({
      title,
      content: content || "",
      tenant: req.tenantId,
      user: req.user._id,
    });

    res.status(201).json(note);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Server error" });
  }
});

// GET ALL NOTES
router.get("/", authMiddleware, ensureTenant, async (req, res) => {
  try {
    const notes = await Note.find({ tenant: req.tenantId }).sort({ createdAt: -1 });
    res.json(notes);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Server error" });
  }
});

// GET NOTE BY ID
router.get("/:id", authMiddleware, ensureTenant, async (req, res) => {
  try {
    const note = await Note.findOne({ _id: req.params.id, tenant: req.tenantId });
    if (!note) return res.status(404).json({ message: "Note not found" });
    res.json(note);
  } catch (err) {
    console.error(err);
    res.status(400).json({ message: "Invalid ID or server error" });
  }
});

// UPDATE NOTE
router.put("/:id", authMiddleware, ensureTenant, async (req, res) => {
  try {
    const note = await Note.findOne({ _id: req.params.id, tenant: req.tenantId });
    if (!note) return res.status(404).json({ message: "Note not found" });

    const isOwner = note.user.toString() === req.user._id.toString();
    const isAdmin = req.user.role && req.user.role.toLowerCase() === "admin";
    if (!isOwner && !isAdmin) return res.status(403).json({ message: "Forbidden" });

    const { title, content } = req.body;
    if (title !== undefined) note.title = title;
    if (content !== undefined) note.content = content;
    await note.save();

    res.json(note);
  } catch (err) {
    console.error(err);
    res.status(400).json({ message: "Invalid ID or server error" });
  }
});

// DELETE NOTE
router.delete("/:id", authMiddleware, ensureTenant, async (req, res) => {
  try {
    const note = await Note.findOne({ _id: req.params.id, tenant: req.tenantId });
    if (!note) return res.status(404).json({ message: "Note not found" });

    const isOwner = note.user.toString() === req.user._id.toString();
    const isAdmin = req.user.role && req.user.role.toLowerCase() === "admin";
    if (!isOwner && !isAdmin) return res.status(403).json({ message: "Forbidden" });

    await note.remove();
    res.json({ message: "Note deleted" });
  } catch (err) {
    console.error(err);
    res.status(400).json({ message: "Invalid ID or server error" });
  }
});

module.exports = router;
