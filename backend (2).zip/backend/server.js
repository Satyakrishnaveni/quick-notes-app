// require('dotenv').config();
// const express = require("express");
// const dotenv = require("dotenv");
// const cors = require("cors");
// const connectDB = require("./utils/db");

// dotenv.config();
// connectDB();

// const app = express();
// app.use(cors());
// app.use(express.json());

// // ✅ authRoutes ని import చేసి వాడాలి
// const authRoutes = require("./routes/authRoutes");

// // Routes
// app.use("/api/auth", authRoutes);  // /api/auth/login → ఇప్పుడు పని చేస్తుంది
// app.use("/api/notes", require("./routes/noteRoutes"));
// app.use("/api/tenants", require("./routes/tenantRoutes"));

// app.get("/health", (req, res) => res.json({ status: "ok" }));

// const PORT = process.env.PORT || 5000;
// app.listen(PORT, () => console.log(`Server running on port ${PORT}`));



require('dotenv').config(); // dotenv load first
const express = require("express");
const cors = require("cors");
const connectDB = require("./utils/db");

// Connect to MongoDB
connectDB();

const app = express();

// Middleware

app.use(cors());
app.use(express.json());

// --------------------- ROUTES ---------------------
const authRoutes = require("./routes/authRoutes");
const noteRoutes = require("./routes/noteRoutes");
const tenantRoutes = require("./routes/tenantRoutes");

// Use routes
app.use("/api/auth", authRoutes);      // /api/auth/login
app.use("/api/notes", noteRoutes);     // /api/notes
app.use("/api/tenants", tenantRoutes); // /api/tenants

// Health check
app.get("/health", (req, res) => res.json({ status: "ok" }));

// Start server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));







